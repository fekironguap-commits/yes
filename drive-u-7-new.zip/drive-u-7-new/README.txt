DRIVE-U-7-NEW
1. Descomprime drive-u-7-new.zip.
2. Entra a https://app.netlify.com/drop
3. Arrastra la carpeta drive-u-7-new (o el ZIP descomprimido) a la zona de despliegue.
4. En Netlify, abre Site configuration / Domain management y cambia el nombre del sitio a drive-u-7-new si está disponible.
5. Tu dirección será https://drive-u-7-new.netlify.app si el nombre está libre.

Esta entrega recrea la página principal en formato compacto. Los enlaces de categorías abren las páginas originales de Google Sites; no se han descargado ni duplicado los archivos de los juegos.
